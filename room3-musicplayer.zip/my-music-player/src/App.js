import { useEffect, useState } from "react"; 
import useSound from "use-sound"; // for handling the sound
import song from "./Arijit Singh - Dhokha(PagalWorld.com.se).mp3"; // importing the music
import song1 from "./Kahani Suno(PagalWorld.com.se).mp3"
import song2 from "./Maan Meri Jaan(PagalWorld.com.se).mp3"
import { AiFillPlayCircle, AiFillPauseCircle } from "react-icons/ai"; // icons for play and pause
import { BiSkipNext, BiSkipPrevious } from "react-icons/bi"; // icons for next and previous track
import { IconContext } from "react-icons"; // for customazing the icons
import './App.css';

// import listReactFiles from 'list-react-files'
 
// listReactFiles('.').then(files => console.log(files))


function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const songs = [song,song1,song2]
  const randnum = Math.floor(Math.random() * songs.length);
  const [play, { pause, duration, sound }] = useSound(songs[0]);

  const [currTime, setCurrTime] = useState({
    min: "",
    sec: "",
  }); // current position of the audio in minutes and seconds

  const [seconds, setSeconds] = useState(); // current position of the a

  useEffect(() => {
    const interval = setInterval(() => {
      if (sound) {
        setSeconds(sound.seek([])); // setting the seconds state with the current state
        const min = Math.floor(sound.seek([]) / 60);
        const sec = Math.floor(sound.seek([]) % 60);
        setCurrTime({
          min,
          sec,
        });
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [sound]);

  const playingButton = () => {
    if (isPlaying) {
      pause(); // this will pause the audio
      setIsPlaying(false);
      console.log(song)
    } else {
      play(); // this will play the audio
      setIsPlaying(true);
    }
  };
  const playNext = () => {
    const [playButtonClick] = useSound(songs[randnum]);
    playButtonClick()
    setIsPlaying(true);
  }
  return (
    <div className="component">
    <h2>Playing Now</h2>
    <img
      className="musicCover"
      src="https://picsum.photos/200/200"
      alt="music player"
    />
    <div>
      <h3 className="title">{song}</h3>
    </div>
    <div>
        <div className="time">
          <p>
            {currTime.min}:{currTime.sec}
          </p>
          {/* <p>
            {time.min}:{time.sec}
          </p> */}
        </div>
        <input
          type="range"
          min="0"
          max={duration / 1000}
          default="0"
          value={seconds}
          className="timeline"
          onChange={(e) => {
            sound.seek([e.target.value]);
          }}
        />
      </div>
    <div>
      <button className="playButton" onClick={playNext}>
        <IconContext.Provider value={{ size: "3em", color: "#27AE60" }}>
          <BiSkipPrevious />
        </IconContext.Provider>
      </button>
      {!isPlaying ? (
        <button className="playButton" onClick={playingButton}>
          <IconContext.Provider value={{ size: "3em", color: "#27AE60" }}>
            <AiFillPlayCircle />
          </IconContext.Provider>
        </button>
      ) : (
        <button className="playButton" onClick={playingButton}>
          <IconContext.Provider value={{ size: "3em", color: "#27AE60" }}>
            <AiFillPauseCircle />
          </IconContext.Provider>
        </button>
      )}
      <button className="playButton" onClick={playNext}>
        <IconContext.Provider value={{ size: "3em", color: "#27AE60" }}>
          <BiSkipNext />
        </IconContext.Provider>
      </button>
    </div>
  </div>
  );
}

export default MusicPlayer;
